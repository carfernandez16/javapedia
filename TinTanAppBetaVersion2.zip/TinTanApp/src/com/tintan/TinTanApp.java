package com.tintan;

import com.tintan.ui.TinTanMainFrame;

/**
 * Created by cfernandez
 * on 5/17/17.
 */
public class TinTanApp {

    public static void main(String args[]){
        TinTanMainFrame mainFrame = new TinTanMainFrame();
        mainFrame.iniciarGUI();
    }

}
